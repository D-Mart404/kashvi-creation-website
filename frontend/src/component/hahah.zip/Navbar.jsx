import Logo from "./Logo";
import Nav from "./Nav";

export default function Navbar() {
  return (
    <header className="bg-white sticky top-0 z-20 w-full border-b border-black-500 p-6 flex items-center justify-between">
      <Logo />
      <h1 className="text-xl font-bold text-black">Kashvi-Creation</h1>
      <Nav />
    </header>
  );
}
